@echo off
title End Realms telepito
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\install.ps1"
if errorlevel 1 echo. & echo HIBA: a telepites nem sikerult, olvasd el a fenti uzenetet.
echo.
pause
