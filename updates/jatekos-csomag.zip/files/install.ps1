﻿param([string]$MinecraftDir = (Join-Path $env:APPDATA '.minecraft'), [string]$Desktop = [Environment]::GetFolderPath('Desktop'))
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $PSScriptRoot
$versionName = 'End Realms 26.3'
$hostAddress = 'impairment-wimp.tun.ply.gg:20574'
$serverName = 'End Realms szerver'
$clientUrl = 'https://piston-data.mojang.com/v1/objects/e877b6a07acd633fb3bb475002175cec036e7b87/client.jar'
$clientSha1 = 'e877b6a07acd633fb3bb475002175cec036e7b87'

function Done($text) { Write-Host ''; Write-Host $text -ForegroundColor Green }

Write-Host '=== End Realms telepito ===' -ForegroundColor Cyan
if (-not (Test-Path (Join-Path $here 'files'))) {
    throw 'Elobb csomagold ki a teljes zip fajlt egy mappaba, es onnan inditsd a TELEPITES.bat-ot.'
}
if (-not (Test-Path $MinecraftDir)) {
    throw "Nem talalom a Minecraft mappat ($MinecraftDir). Inditsd el egyszer a TLaunchert, aztan probald ujra."
}

$target = Join-Path (Join-Path $MinecraftDir 'versions') $versionName
$mods = Join-Path $target 'mods'
New-Item -ItemType Directory -Force $mods | Out-Null

foreach ($jar in Get-ChildItem $mods -Filter '*.jar' -ErrorAction SilentlyContinue) {
    try { $stream = [IO.File]::Open($jar.FullName, 'Open', 'ReadWrite', 'None'); $stream.Close() }
    catch { throw 'A Minecraft most fut, es fogja a modokat. Zard be a jatekot (es a TLaunchert), aztan probald ujra.' }
}

Write-Host 'Modok masolasa...'
Get-ChildItem $mods -Filter '*.jar' -ErrorAction SilentlyContinue | Remove-Item -Force
Copy-Item (Join-Path $here 'files\mods\*.jar') $mods -Force

Write-Host 'Jatekverzio beallitasa...'
$json = [IO.File]::ReadAllText((Join-Path $here 'files\version.json'), [Text.Encoding]::UTF8)
$json = $json.Replace('__MODS__', $mods.Replace('\', '\\'))
[IO.File]::WriteAllText((Join-Path $target "$versionName.json"), $json, (New-Object Text.UTF8Encoding($false)))
Copy-Item (Join-Path $here 'files\TLauncherAdditional.json') $target -Force

$jar = Join-Path $target "$versionName.jar"
function Sha1Of($path) { (Get-FileHash $path -Algorithm SHA1).Hash.ToLower() }
if (-not (Test-Path $jar) -or (Sha1Of $jar) -ne $clientSha1) {
    Write-Host 'Minecraft 26.3 letoltese a Mojangtol (kb. 40 MB)...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $ProgressPreference = 'SilentlyContinue'
    Invoke-WebRequest -Uri $clientUrl -OutFile $jar -UseBasicParsing
    if ((Sha1Of $jar) -ne $clientSha1) { Remove-Item $jar -Force; throw 'A letoltott jatekfajl serult. Probald ujra.' }
}

Write-Host 'Szerver hozzaadasa a listahoz...'
$servers = Join-Path $MinecraftDir 'servers.dat'
$added = $false
if (-not (Test-Path $servers)) {
    Copy-Item (Join-Path $here 'files\servers.dat') $servers
    $added = $true
} else {
    $bytes = [IO.File]::ReadAllBytes($servers)
    $text = [Text.Encoding]::UTF8.GetString($bytes)
    $name = [Text.Encoding]::ASCII.GetString($bytes, [Math]::Min(6, $bytes.Length - 1), [Math]::Min(7, $bytes.Length - 6))
    if ($text.Contains($hostAddress)) {
        $added = $true
    } elseif ($bytes.Length -gt 17 -and $bytes[0] -eq 10 -and $bytes[3] -eq 9 -and $name -eq 'servers' -and ($bytes[13] -eq 10 -or $bytes[13] -eq 0) -and $bytes[$bytes.Length - 1] -eq 0) {
        Copy-Item $servers "$servers.endrealms-bak" -Force
        $entry = [IO.File]::ReadAllBytes((Join-Path $here 'files\servers.dat'))
        $count = ([int]$bytes[14] -shl 24) + ([int]$bytes[15] -shl 16) + ([int]$bytes[16] -shl 8) + [int]$bytes[17] + 1
        $body = $entry[18..($entry.Length - 2)]
        $out = New-Object IO.MemoryStream
        $out.Write($bytes, 0, 13)
        $out.WriteByte(10)
        $out.WriteByte(($count -shr 24) -band 255); $out.WriteByte(($count -shr 16) -band 255); $out.WriteByte(($count -shr 8) -band 255); $out.WriteByte($count -band 255)
        $out.Write($bytes, 18, $bytes.Length - 19)
        $out.Write($body, 0, $body.Length)
        $out.WriteByte(0)
        [IO.File]::WriteAllBytes($servers, $out.ToArray())
        $added = $true
    }
}

Write-Host 'Frissito elhelyezese az asztalon...'
Copy-Item (Join-Path $here 'files\frissites.ps1') (Join-Path $target 'frissites.ps1') -Force
if ($Desktop -and (Test-Path $Desktop)) {
    $bat = "@echo off`r`ntitle End Realms frissito`r`npowershell -NoProfile -ExecutionPolicy Bypass -File `"$target\frissites.ps1`"`r`nif errorlevel 1 echo. & echo HIBA: a frissites nem sikerult, olvasd el a fenti uzenetet.`r`necho.`r`npause`r`n"
    [IO.File]::WriteAllText((Join-Path $Desktop 'End Realms frissites.bat'), $bat, [Text.Encoding]::ASCII)
}

Done 'Kesz! A telepites sikerult.'
Write-Host ''
Write-Host "1. A TLauncherben valaszd ki ezt a verziot: $versionName"
Write-Host '   (Ha nem latod, kapcsold be a modositott verziok mutatasat a beallitasokban, vagy inditsd ujra a TLaunchert.)'
Write-Host '2. Inditsd el a jatekot. Az elso inditasnal a TLauncher letolti a hianyzo fajlokat, ez par percig tarthat.'
Write-Host '   Kesobb, ha a szerver uj modokat kap: inditsd el az asztalon az "End Realms frissites" fajlt, az mindent letolt.'
if ($added) { Write-Host "3. Tobbjatekos menu: ott talalod a szervert ($serverName)." } else { Write-Host "3. Tobbjatekos menu: add hozza kezzel ezt a cimet: $hostAddress" }
Write-Host '4. Elso belepeskor irj jelszot:  /register jelszo jelszo     kesobb:  /login jelszo'
