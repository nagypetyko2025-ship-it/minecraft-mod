﻿# End Realms frissito: letolti a legujabb jatekos-csomagot a GitHubrol, es lefuttatja a telepitojet.
$ErrorActionPreference = 'Stop'
$url = 'https://raw.githubusercontent.com/nagypetyko2025-ship-it/minecraft-mod/main/updates/jatekos-csomag.zip'
Write-Host '=== End Realms frissito ===' -ForegroundColor Cyan
$tmp = Join-Path $env:TEMP 'endrealms-frissites'
if (Test-Path $tmp) { Remove-Item -Recurse -Force $tmp }
New-Item -ItemType Directory -Force $tmp | Out-Null
Write-Host 'A legujabb csomag letoltese...'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ProgressPreference = 'SilentlyContinue'
Invoke-WebRequest -Uri $url -OutFile (Join-Path $tmp 'csomag.zip') -UseBasicParsing
Expand-Archive -LiteralPath (Join-Path $tmp 'csomag.zip') -DestinationPath (Join-Path $tmp 'csomag') -Force
& (Join-Path $tmp 'csomag\files\install.ps1')
Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
